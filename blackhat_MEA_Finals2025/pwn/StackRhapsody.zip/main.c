#include <stdio.h>
#include <stdlib.h>

int main() {
  char buf[0x10000];
  fgets(buf, 0x100000, stdin);
  system("echo Are you a good pwner?");
  return 0;
}
